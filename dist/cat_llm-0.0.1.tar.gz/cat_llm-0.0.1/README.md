# cat_llm

[![PyPI - Version](https://img.shields.io/pypi/v/cat-llm.svg)](https://pypi.org/project/cat-llm)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/cat-llm.svg)](https://pypi.org/project/cat-llm)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install cat-llm
```

## License

`cat-llm` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
