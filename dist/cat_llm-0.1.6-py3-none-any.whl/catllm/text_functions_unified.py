"""
Unified HTTP-based multi-class text classification.

This module uses raw HTTP requests (via `requests`) for all LLM providers,
eliminating the need for provider-specific SDKs like openai, anthropic, mistralai, etc.
"""

import json
import time
import requests
import pandas as pd
import regex
from tqdm import tqdm


# =============================================================================
# Provider Configuration
# =============================================================================

PROVIDER_CONFIG = {
    "openai": {
        "endpoint": "https://api.openai.com/v1/chat/completions",
        "auth_header": "Authorization",
        "auth_prefix": "Bearer ",
    },
    "anthropic": {
        "endpoint": "https://api.anthropic.com/v1/messages",
        "auth_header": "x-api-key",
        "auth_prefix": "",
    },
    "google": {
        "endpoint": "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
        "auth_header": "x-goog-api-key",
        "auth_prefix": "",
    },
    "mistral": {
        "endpoint": "https://api.mistral.ai/v1/chat/completions",
        "auth_header": "Authorization",
        "auth_prefix": "Bearer ",
    },
    "perplexity": {
        "endpoint": "https://api.perplexity.ai/chat/completions",
        "auth_header": "Authorization",
        "auth_prefix": "Bearer ",
    },
    "xai": {
        "endpoint": "https://api.x.ai/v1/chat/completions",
        "auth_header": "Authorization",
        "auth_prefix": "Bearer ",
    },
    "huggingface": {
        "endpoint": "https://router.huggingface.co/v1/chat/completions",
        "auth_header": "Authorization",
        "auth_prefix": "Bearer ",
    },
    "ollama": {
        "endpoint": "http://localhost:11434/v1/chat/completions",
        "auth_header": None,  # No auth required for local Ollama
        "auth_prefix": "",
    },
}


# =============================================================================
# Unified API Client
# =============================================================================

class UnifiedLLMClient:
    """A unified client for calling various LLM providers via HTTP."""

    def __init__(self, provider: str, api_key: str, model: str):
        self.provider = provider.lower()
        self.api_key = api_key
        self.model = model

        if self.provider not in PROVIDER_CONFIG:
            raise ValueError(f"Unsupported provider: {provider}. "
                           f"Supported: {list(PROVIDER_CONFIG.keys())}")

        self.config = PROVIDER_CONFIG[self.provider]

    def _get_endpoint(self) -> str:
        """Get the API endpoint, substituting model if needed."""
        endpoint = self.config["endpoint"]
        if "{model}" in endpoint:
            endpoint = endpoint.format(model=self.model)
        return endpoint

    def _get_headers(self) -> dict:
        """Build request headers for the provider."""
        headers = {"Content-Type": "application/json"}
        auth_header = self.config["auth_header"]
        auth_prefix = self.config["auth_prefix"]

        # Some providers (like Ollama) don't require auth
        if auth_header is not None:
            headers[auth_header] = f"{auth_prefix}{self.api_key}"

        # Anthropic requires additional headers
        if self.provider == "anthropic":
            headers["anthropic-version"] = "2023-06-01"

        return headers

    def _build_payload(
        self,
        messages: list,
        json_schema: dict = None,
        creativity: float = None,
        max_tokens: int = 4096,
    ) -> dict:
        """Build the request payload for the specific provider."""

        if self.provider == "anthropic":
            return self._build_anthropic_payload(messages, json_schema, creativity, max_tokens)
        elif self.provider == "google":
            return self._build_google_payload(messages, json_schema, creativity)
        else:
            # OpenAI-compatible providers
            return self._build_openai_payload(messages, json_schema, creativity)

    def _build_openai_payload(
        self,
        messages: list,
        json_schema: dict = None,
        creativity: float = None,
    ) -> dict:
        """Build payload for OpenAI-compatible APIs."""
        payload = {
            "model": self.model,
            "messages": messages,
        }

        # Structured output
        # Ollama only supports json_object mode, not strict json_schema
        if json_schema and self.provider not in ["ollama"]:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "classification_result",
                    "strict": True,
                    "schema": json_schema,
                }
            }
        else:
            payload["response_format"] = {"type": "json_object"}

        if creativity is not None:
            payload["temperature"] = creativity

        return payload

    def _build_anthropic_payload(
        self,
        messages: list,
        json_schema: dict = None,
        creativity: float = None,
        max_tokens: int = 4096,
    ) -> dict:
        """Build payload for Anthropic API."""
        # Extract system message if present
        system_content = None
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_content = msg["content"]
            else:
                user_messages.append(msg)

        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": user_messages,
        }

        if system_content:
            payload["system"] = system_content

        if creativity is not None:
            payload["temperature"] = creativity

        # Use tool calling for structured output (most reliable for Anthropic)
        if json_schema:
            payload["tools"] = [{
                "name": "return_categories",
                "description": "Return categorization results",
                "input_schema": json_schema,
            }]
            payload["tool_choice"] = {"type": "tool", "name": "return_categories"}

        return payload

    def _build_google_payload(
        self,
        messages: list,
        json_schema: dict = None,
        creativity: float = None,
    ) -> dict:
        """Build payload for Google Gemini API."""
        # Convert messages to Google format
        # Combine system + user messages into a single prompt
        combined_text = ""
        for msg in messages:
            if msg["role"] == "system":
                combined_text += msg["content"] + "\n\n"
            elif msg["role"] == "user":
                combined_text += msg["content"]

        payload = {
            "contents": [{"parts": [{"text": combined_text}]}],
            "generationConfig": {}
        }

        if json_schema:
            payload["generationConfig"]["responseMimeType"] = "application/json"
            payload["generationConfig"]["responseSchema"] = json_schema
        else:
            payload["generationConfig"]["responseMimeType"] = "application/json"

        if creativity is not None:
            payload["generationConfig"]["temperature"] = creativity

        return payload

    def _parse_response(self, response_json: dict) -> str:
        """Parse the response based on provider format."""
        if self.provider == "anthropic":
            return self._parse_anthropic_response(response_json)
        elif self.provider == "google":
            return self._parse_google_response(response_json)
        else:
            # OpenAI-compatible
            return self._parse_openai_response(response_json)

    def _parse_openai_response(self, response_json: dict) -> str:
        """Parse OpenAI-compatible response."""
        return response_json["choices"][0]["message"]["content"]

    def _parse_anthropic_response(self, response_json: dict) -> str:
        """Parse Anthropic response (handles both text and tool use)."""
        content = response_json.get("content", [])
        for block in content:
            if block.get("type") == "tool_use":
                # Return the tool input as JSON string
                return json.dumps(block.get("input", {}))
            elif block.get("type") == "text":
                return block.get("text", "")
        return ""

    def _parse_google_response(self, response_json: dict) -> str:
        """Parse Google Gemini response."""
        candidates = response_json.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            if parts:
                return parts[0].get("text", "")
        return ""

    def complete(
        self,
        messages: list,
        json_schema: dict = None,
        creativity: float = None,
        max_retries: int = 5,
        initial_delay: float = 2.0,
    ) -> tuple[str, str | None]:
        """
        Make a completion request to the LLM provider.

        Returns:
            tuple: (response_text, error_message)
                   error_message is None on success
        """
        endpoint = self._get_endpoint()
        headers = self._get_headers()
        payload = self._build_payload(messages, json_schema, creativity)

        for attempt in range(max_retries):
            try:
                response = requests.post(
                    endpoint,
                    headers=headers,
                    json=payload,
                    timeout=120,
                )

                # Check for HTTP errors
                if response.status_code == 404:
                    return None, f"Model '{self.model}' not found for {self.provider}"
                elif response.status_code in [401, 403]:
                    return None, f"Authentication failed for {self.provider}"
                elif response.status_code == 429:
                    # Rate limited - retry with backoff
                    if attempt < max_retries - 1:
                        wait_time = initial_delay * (2 ** attempt) * 5  # Longer wait for rate limits
                        print(f"⚠️ Rate limited. Waiting {wait_time}s...")
                        time.sleep(wait_time)
                        continue
                    else:
                        return None, "Rate limit exceeded after retries"
                elif response.status_code >= 500:
                    # Server error - retry
                    if attempt < max_retries - 1:
                        wait_time = initial_delay * (2 ** attempt)
                        print(f"⚠️ Server error {response.status_code}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                        continue
                    else:
                        return None, f"Server error {response.status_code} after retries"

                response.raise_for_status()
                response_json = response.json()
                result = self._parse_response(response_json)
                return result, None

            except requests.exceptions.Timeout:
                if attempt < max_retries - 1:
                    wait_time = initial_delay * (2 ** attempt)
                    print(f"⚠️ Request timeout. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    return None, "Request timeout after retries"

            except requests.exceptions.RequestException as e:
                if attempt < max_retries - 1:
                    wait_time = initial_delay * (2 ** attempt)
                    print(f"⚠️ Request error: {e}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    return None, f"Request failed: {e}"

            except json.JSONDecodeError as e:
                return None, f"Failed to parse response JSON: {e}"

        return None, "Max retries exceeded"


# =============================================================================
# Helper Functions
# =============================================================================

def detect_provider(model_name: str, provider: str = "auto") -> str:
    """Auto-detect provider from model name if not explicitly provided."""
    if provider and provider.lower() != "auto":
        return provider.lower()

    model_lower = model_name.lower()

    if "gpt" in model_lower or "o1" in model_lower or "o3" in model_lower:
        return "openai"
    elif "claude" in model_lower:
        return "anthropic"
    elif "gemini" in model_lower or "gemma" in model_lower:
        return "google"
    elif "mistral" in model_lower or "mixtral" in model_lower:
        return "mistral"
    elif "sonar" in model_lower or "pplx" in model_lower:
        return "perplexity"
    elif "grok" in model_lower:
        return "xai"
    elif "llama" in model_lower or "meta" in model_lower or "deepseek" in model_lower or "qwen" in model_lower:
        return "huggingface"
    else:
        raise ValueError(
            f"Could not auto-detect provider from '{model_name}'. "
            "Please specify provider explicitly: openai, anthropic, google, mistral, "
            "perplexity, xai, huggingface, or ollama."
        )


def set_ollama_endpoint(host: str = "localhost", port: int = 11434):
    """
    Configure a custom Ollama endpoint.

    Useful if Ollama is running on a different host or port.

    Args:
        host: Hostname where Ollama is running (default: localhost)
        port: Port number (default: 11434)

    Example:
        set_ollama_endpoint("192.168.1.100", 11434)
    """
    PROVIDER_CONFIG["ollama"]["endpoint"] = f"http://{host}:{port}/v1/chat/completions"


def check_ollama_running(host: str = "localhost", port: int = 11434) -> bool:
    """
    Check if Ollama is running and accessible.

    Args:
        host: Hostname where Ollama should be running
        port: Port number

    Returns:
        True if Ollama is running, False otherwise
    """
    try:
        response = requests.get(f"http://{host}:{port}/api/tags", timeout=5)
        return response.status_code == 200
    except requests.exceptions.RequestException:
        return False


def list_ollama_models(host: str = "localhost", port: int = 11434) -> list:
    """
    List all models available in the local Ollama installation.

    Args:
        host: Hostname where Ollama is running
        port: Port number

    Returns:
        List of model names, or empty list if Ollama is not running
    """
    try:
        response = requests.get(f"http://{host}:{port}/api/tags", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return [model["name"] for model in data.get("models", [])]
        return []
    except requests.exceptions.RequestException:
        return []


def check_ollama_model(model: str, host: str = "localhost", port: int = 11434) -> bool:
    """
    Check if a specific model is available in Ollama.

    Args:
        model: Model name to check (e.g., "llama3.2", "mistral")
        host: Hostname where Ollama is running
        port: Port number

    Returns:
        True if model is available, False otherwise
    """
    available_models = list_ollama_models(host, port)
    # Check for exact match or partial match (e.g., "llama3.2" matches "llama3.2:latest")
    model_lower = model.lower()
    return any(
        model_lower == m.lower() or
        m.lower().startswith(f"{model_lower}:") or
        model_lower.startswith(m.lower().split(":")[0])
        for m in available_models
    )


def _format_bytes(size_bytes: int) -> str:
    """Format bytes into human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / (1024 ** 2):.1f} MB"
    else:
        return f"{size_bytes / (1024 ** 3):.2f} GB"


def _parse_size_string(size_str: str) -> int:
    """Parse a size string like '2.0 GB' into bytes."""
    if size_str == "unknown":
        return 0

    size_str = size_str.strip().upper()
    try:
        if "GB" in size_str:
            return int(float(size_str.replace("GB", "").strip()) * 1024 ** 3)
        elif "MB" in size_str:
            return int(float(size_str.replace("MB", "").strip()) * 1024 ** 2)
        elif "KB" in size_str:
            return int(float(size_str.replace("KB", "").strip()) * 1024)
        else:
            return int(float(size_str.replace("B", "").strip()))
    except ValueError:
        return 0


def check_system_resources(model: str) -> dict:
    """
    Check if system has enough resources to download and run a model.

    Args:
        model: Model name to check

    Returns:
        dict with 'can_download', 'can_run', 'warnings', and 'details'
    """
    import shutil
    import os

    result = {
        "can_download": True,
        "can_run": True,
        "warnings": [],
        "details": {}
    }

    size_estimate = get_ollama_model_size_estimate(model)
    model_size_bytes = _parse_size_string(size_estimate)

    # Check disk space (Ollama typically stores models in ~/.ollama)
    ollama_dir = os.path.expanduser("~/.ollama")
    if not os.path.exists(ollama_dir):
        ollama_dir = os.path.expanduser("~")

    try:
        disk_usage = shutil.disk_usage(ollama_dir)
        free_space = disk_usage.free
        result["details"]["free_disk_space"] = _format_bytes(free_space)
        result["details"]["model_size"] = size_estimate

        # Need at least 1.5x model size for download + extraction
        required_space = int(model_size_bytes * 1.5) if model_size_bytes > 0 else 0

        if required_space > 0 and free_space < required_space:
            result["can_download"] = False
            result["warnings"].append(
                f"Insufficient disk space. Need ~{_format_bytes(required_space)}, "
                f"but only {_format_bytes(free_space)} available."
            )
        elif required_space > 0 and free_space < required_space * 2:
            result["warnings"].append(
                f"Low disk space warning: {_format_bytes(free_space)} available."
            )
    except Exception:
        result["details"]["free_disk_space"] = "unknown"

    # Estimate RAM requirements (rough guide: model size * 1.2 for inference)
    # This is approximate - actual requirements vary by quantization
    if model_size_bytes > 0:
        estimated_ram = model_size_bytes * 1.2
        result["details"]["estimated_ram"] = _format_bytes(int(estimated_ram))

        # Try to get system RAM (works on most systems)
        try:
            import subprocess
            if os.name == 'posix':  # Linux/macOS
                if os.path.exists('/proc/meminfo'):  # Linux
                    with open('/proc/meminfo', 'r') as f:
                        for line in f:
                            if line.startswith('MemTotal:'):
                                total_ram = int(line.split()[1]) * 1024  # Convert KB to bytes
                                break
                else:  # macOS
                    output = subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)
                    total_ram = int(output.strip())

                result["details"]["total_ram"] = _format_bytes(total_ram)

                if estimated_ram > total_ram * 0.8:
                    result["can_run"] = False
                    result["warnings"].append(
                        f"Model may be too large for your system. "
                        f"Requires ~{_format_bytes(int(estimated_ram))} RAM, "
                        f"but system has {_format_bytes(total_ram)}."
                    )
                elif estimated_ram > total_ram * 0.5:
                    result["warnings"].append(
                        f"Model will use significant RAM (~{_format_bytes(int(estimated_ram))})."
                    )
        except Exception:
            result["details"]["total_ram"] = "unknown"
            # If we can't check RAM, warn for large models
            if model_size_bytes > 8 * 1024 ** 3:  # > 8GB models
                result["warnings"].append(
                    f"Large model (~{size_estimate}). Ensure you have sufficient RAM."
                )

    return result


# Common model sizes (approximate) for user reference
OLLAMA_MODEL_SIZES = {
    "llama3.2": "2.0 GB",
    "llama3.2:1b": "1.3 GB",
    "llama3.2:3b": "2.0 GB",
    "llama3.1": "4.7 GB",
    "llama3.1:8b": "4.7 GB",
    "llama3.1:70b": "40 GB",
    "llama3": "4.7 GB",
    "llama2": "3.8 GB",
    "mistral": "4.1 GB",
    "mixtral": "26 GB",
    "phi3": "2.2 GB",
    "phi3:mini": "2.2 GB",
    "gemma": "5.0 GB",
    "gemma:2b": "1.7 GB",
    "gemma:7b": "5.0 GB",
    "gemma2": "5.4 GB",
    "gemma2:2b": "1.6 GB",
    "gemma2:9b": "5.4 GB",
    "gemma2:27b": "16 GB",
    "qwen2.5": "4.7 GB",
    "qwen2.5:0.5b": "397 MB",
    "qwen2.5:1.5b": "986 MB",
    "qwen2.5:3b": "1.9 GB",
    "qwen2.5:7b": "4.7 GB",
    "deepseek-r1": "4.7 GB",
    "codellama": "3.8 GB",
    "codegemma": "5.0 GB",
    "nomic-embed-text": "274 MB",
}


def get_ollama_model_size_estimate(model: str) -> str:
    """
    Get estimated download size for an Ollama model.

    Args:
        model: Model name

    Returns:
        Human-readable size estimate or "unknown"
    """
    model_lower = model.lower()

    # Check exact match first
    if model_lower in OLLAMA_MODEL_SIZES:
        return OLLAMA_MODEL_SIZES[model_lower]

    # Check base model name (without tag)
    base_model = model_lower.split(":")[0]
    if base_model in OLLAMA_MODEL_SIZES:
        return OLLAMA_MODEL_SIZES[base_model]

    return "unknown"


def pull_ollama_model(model: str, host: str = "localhost", port: int = 11434, auto_confirm: bool = False) -> bool:
    """
    Pull/download a model in Ollama.

    Args:
        model: Model name to pull (e.g., "llama3.2", "mistral")
        host: Hostname where Ollama is running
        port: Port number
        auto_confirm: If True, skip confirmation prompt

    Returns:
        True if model was pulled successfully, False otherwise
    """
    # Get size estimate and check system resources
    size_estimate = get_ollama_model_size_estimate(model)
    resources = check_system_resources(model)

    print(f"\n{'='*60}")
    print(f"  Model '{model}' not found locally")
    print(f"{'='*60}")
    print(f"  Model size:      {size_estimate}")
    if resources["details"].get("estimated_ram"):
        print(f"  RAM required:    ~{resources['details']['estimated_ram']}")
    if resources["details"].get("free_disk_space"):
        print(f"  Free disk space: {resources['details']['free_disk_space']}")
    if resources["details"].get("total_ram"):
        print(f"  System RAM:      {resources['details']['total_ram']}")

    # Show warnings
    if resources["warnings"]:
        print(f"\n  {'!'*50}")
        for warning in resources["warnings"]:
            print(f"  ⚠️  {warning}")
        print(f"  {'!'*50}")

    # Block if can't download
    if not resources["can_download"]:
        print(f"\n  ❌ Cannot download: insufficient disk space.")
        print(f"  Free up disk space and try again.")
        return False

    # Warn but allow if can't run (user might want to try anyway)
    if not resources["can_run"]:
        print(f"\n  ⚠️  Warning: Model may not run on this system.")
        print(f"  Consider a smaller model variant (e.g., '{model}:1b' or '{model}:3b').")

    print(f"{'='*60}")

    # Ask for confirmation
    if not auto_confirm:
        try:
            if not resources["can_run"]:
                prompt = f"\n  Download anyway? [y/N]: "
            else:
                prompt = f"\n  Download '{model}'? [y/N]: "
            response = input(prompt).strip().lower()
            if response not in ['y', 'yes']:
                print("  Download cancelled.")
                return False
        except (EOFError, KeyboardInterrupt):
            print("\n  Download cancelled.")
            return False

    print(f"\n  Downloading from Ollama registry...")
    print(f"  (Press Ctrl+C to cancel)\n")

    try:
        # Ollama pull endpoint streams the response
        response = requests.post(
            f"http://{host}:{port}/api/pull",
            json={"name": model},
            stream=True,
            timeout=None  # No timeout - large models can take a while
        )

        if response.status_code != 200:
            print(f"Failed to pull model: HTTP {response.status_code}")
            return False

        # Process streaming response to show progress
        last_status = ""
        total_size_shown = False

        for line in response.iter_lines():
            if line:
                try:
                    data = json.loads(line)
                    status = data.get("status", "")

                    # Show progress for downloads
                    if "completed" in data and "total" in data:
                        completed = data["completed"]
                        total = data["total"]
                        pct = (completed / total * 100) if total > 0 else 0

                        # Show actual total size on first progress update
                        if not total_size_shown and total > 0:
                            print(f"  Actual size: {_format_bytes(total)}")
                            total_size_shown = True

                        print(f"\r  {status}: {pct:.1f}% ({_format_bytes(completed)}/{_format_bytes(total)})", end="", flush=True)
                    elif status != last_status:
                        if last_status and "completed" in str(last_status):
                            print()  # newline after progress bar
                        print(f"  {status}")
                        last_status = status

                    # Check for errors
                    if "error" in data:
                        print(f"\n  Error: {data['error']}")
                        return False

                except json.JSONDecodeError:
                    continue

        print(f"\n  Model '{model}' downloaded successfully!")
        return True

    except KeyboardInterrupt:
        print(f"\n\n  Download cancelled by user.")
        return False
    except requests.exceptions.Timeout:
        print(f"\n  Timeout while downloading model '{model}'.")
        print(f"  Try again or download manually: ollama pull {model}")
        return False
    except requests.exceptions.RequestException as e:
        print(f"\n  Error pulling model: {e}")
        return False


def build_json_schema(categories: list) -> dict:
    """Build a JSON schema for the classification output."""
    properties = {}
    for i, cat in enumerate(categories, 1):
        properties[str(i)] = {
            "type": "string",
            "enum": ["0", "1"],
            "description": cat,
        }

    return {
        "type": "object",
        "properties": properties,
        "required": list(properties.keys()),
        "additionalProperties": False,
    }


def extract_json(reply: str) -> str:
    """Extract JSON from model reply."""
    if reply is None:
        return '{"1":"e"}'

    extracted = regex.findall(r'\{(?:[^{}]|(?R))*\}', reply, regex.DOTALL)
    if extracted:
        # Clean up the JSON string
        return extracted[0].replace('[', '').replace(']', '').replace('\n', '').replace(" ", '')
    else:
        return '{"1":"e"}'


def validate_classification_json(json_str: str, num_categories: int) -> tuple[bool, dict | None]:
    """
    Validate that a JSON string contains valid classification output.

    Args:
        json_str: The JSON string to validate
        num_categories: Expected number of categories

    Returns:
        tuple: (is_valid, parsed_dict or None)
    """
    try:
        parsed = json.loads(json_str)

        if not isinstance(parsed, dict):
            return False, None

        # Check that all expected keys are present and values are "0" or "1"
        for i in range(1, num_categories + 1):
            key = str(i)
            if key not in parsed:
                return False, None
            val = str(parsed[key]).strip()
            if val not in ("0", "1"):
                return False, None

        # Normalize values to strings
        normalized = {str(i): str(parsed[str(i)]).strip() for i in range(1, num_categories + 1)}
        return True, normalized

    except (json.JSONDecodeError, KeyError, TypeError):
        return False, None


def ollama_two_step_classify(
    client,
    response_text: str,
    categories: list,
    categories_str: str,
    survey_question: str = "",
    creativity: float = None,
    max_retries: int = 5,
) -> tuple[str, str | None]:
    """
    Two-step classification for Ollama models.

    Step 1: Classify the response (natural language output OK)
    Step 2: Convert classification to strict JSON format

    This approach is more reliable for local models that struggle with
    simultaneous reasoning and JSON formatting.

    TODO: Fine-tune a small local model specifically for Step 2 (JSON formatting).
          This would eliminate the need for retries and improve speed/consistency.
          Could train on examples of classification text -> JSON output pairs.

    Args:
        client: UnifiedLLMClient instance
        response_text: The survey response to classify
        categories: List of category names
        categories_str: Pre-formatted category string
        survey_question: Optional context
        creativity: Temperature setting
        max_retries: Number of retry attempts for JSON validation

    Returns:
        tuple: (json_string, error_message or None)
    """
    num_categories = len(categories)
    survey_context = f"A respondent was asked: {survey_question}." if survey_question else ""

    # ==========================================================================
    # Step 1: Classification (natural language - focus on accuracy)
    # ==========================================================================
    step1_messages = [
        {
            "role": "system",
            "content": "You are an expert at categorizing survey responses. Focus on accurate classification."
        },
        {
            "role": "user",
            "content": f"""{survey_context}

Analyze this survey response and determine which categories apply:

Response: "{response_text}"

Categories:
{categories_str}

For each category, explain briefly whether it applies (YES) or not (NO) to this response.
Format your answer as:
1. [Category name]: YES/NO - [brief reason]
2. [Category name]: YES/NO - [brief reason]
...and so on for all categories."""
        }
    ]

    step1_reply, step1_error = client.complete(
        messages=step1_messages,
        json_schema=None,  # No JSON requirement for step 1
        creativity=creativity,
    )

    if step1_error:
        return '{"1":"e"}', f"Step 1 failed: {step1_error}"

    # ==========================================================================
    # Step 2: JSON Formatting with validation and retry
    # ==========================================================================
    example_json = json.dumps({str(i): "0" for i in range(1, num_categories + 1)})

    for attempt in range(max_retries):
        step2_messages = [
            {
                "role": "system",
                "content": "You convert classification results to JSON. Output ONLY valid JSON, nothing else."
            },
            {
                "role": "user",
                "content": f"""Convert this classification to JSON format.

Classification results:
{step1_reply}

Rules:
- Output ONLY a JSON object, no other text
- Use category numbers as keys (1, 2, 3, etc.)
- Use "1" if the category was marked YES, "0" if NO
- Include ALL {num_categories} categories

Example format:
{example_json}

Your JSON output:"""
            }
        ]

        step2_reply, step2_error = client.complete(
            messages=step2_messages,
            json_schema=None,  # Ollama doesn't support strict schema anyway
            creativity=0.1,  # Low temperature for formatting task
        )

        if step2_error:
            if attempt < max_retries - 1:
                continue
            return '{"1":"e"}', f"Step 2 failed: {step2_error}"

        # Extract and validate JSON
        extracted = extract_json(step2_reply)
        is_valid, normalized = validate_classification_json(extracted, num_categories)

        if is_valid:
            return json.dumps(normalized), None

        # If invalid, try again with more explicit instructions
        if attempt < max_retries - 1:
            step1_reply = f"""Previous attempt produced invalid JSON.

Original classification:
{step1_reply}

Please be more careful to output EXACTLY {num_categories} categories numbered 1 through {num_categories}."""

    # All retries exhausted - try to salvage what we can
    extracted = extract_json(step2_reply) if step2_reply else '{"1":"e"}'
    return extracted, f"JSON validation failed after {max_retries} attempts"


# =============================================================================
# Main Classification Function
# =============================================================================

def multi_class_unified(
    survey_input,
    categories: list,
    api_key: str = None,
    model: str = "gpt-4o",
    provider: str = "auto",
    survey_question: str = "",
    creativity: float = None,
    chain_of_thought: bool = True,
    use_json_schema: bool = True,
    filename: str = None,
    auto_download: bool = False,
):
    """
    Multi-class text classification using a unified HTTP-based approach.

    This is a simplified test version that uses raw HTTP requests for all providers,
    eliminating SDK dependencies.

    Args:
        survey_input: List or Series of text responses to classify
        categories: List of category names
        api_key: API key for the LLM provider (not required for Ollama)
        model: Model name (e.g., "gpt-4o", "claude-3-5-sonnet-20241022", "gemini-1.5-flash",
               or any Ollama model like "llama3.2", "mistral", "phi3")
        provider: Provider name or "auto" to detect from model name.
                  For local models, use provider="ollama"
        survey_question: Optional context about what question was asked
        creativity: Temperature setting (None for provider default)
        chain_of_thought: Whether to use step-by-step reasoning in prompt
        use_json_schema: Whether to use strict JSON schema (vs just json_object mode)
        filename: Optional CSV filename to save results
        auto_download: If True, automatically download missing Ollama models without
                      prompting. If False (default), asks for confirmation before downloading.

    Returns:
        DataFrame with classification results

    Example with Ollama (local):
        results = multi_class_unified(
            survey_input=["I moved for work"],
            categories=["Employment", "Family"],
            model="llama3.2",
            provider="ollama",
        )

    Example with cloud provider:
        results = multi_class_unified(
            survey_input=["I moved for work"],
            categories=["Employment", "Family"],
            api_key="your-api-key",
            model="gpt-4o",
        )
    """
    # Detect provider
    provider = detect_provider(model, provider)

    # Validate api_key requirement
    if provider != "ollama" and not api_key:
        raise ValueError(f"api_key is required for provider '{provider}'")

    # Ollama-specific checks
    if provider == "ollama":
        if not check_ollama_running():
            raise ConnectionError(
                "\n" + "="*60 + "\n"
                "  OLLAMA NOT RUNNING\n"
                "="*60 + "\n\n"
                "Ollama must be running to use local models.\n\n"
                "To start Ollama:\n"
                "  macOS:   Open the Ollama app, or run 'ollama serve'\n"
                "  Linux:   Run 'ollama serve' in terminal\n"
                "  Windows: Open the Ollama app\n\n"
                "Don't have Ollama installed?\n"
                "  Download from: https://ollama.ai/download\n\n"
                "After starting Ollama, run your code again.\n"
                + "="*60
            )

        # Check system resources before proceeding
        resources = check_system_resources(model)

        # Check if model needs to be downloaded
        model_installed = check_ollama_model(model)

        if not model_installed:
            # Show resource info and download prompt
            if not pull_ollama_model(model, auto_confirm=auto_download):
                raise RuntimeError(
                    f"Model '{model}' not available. "
                    f"To download manually: ollama pull {model}"
                )
        else:
            # Model is installed - still check if it can run
            if resources["warnings"] or not resources["can_run"]:
                print(f"\n{'='*60}")
                print(f"  Model '{model}' - System Resource Check")
                print(f"{'='*60}")
                size_estimate = get_ollama_model_size_estimate(model)
                print(f"  Model size:      {size_estimate}")
                if resources["details"].get("estimated_ram"):
                    print(f"  RAM required:    ~{resources['details']['estimated_ram']}")
                if resources["details"].get("total_ram"):
                    print(f"  System RAM:      {resources['details']['total_ram']}")

                if resources["warnings"]:
                    print(f"\n  {'!'*50}")
                    for warning in resources["warnings"]:
                        print(f"  ⚠️  {warning}")
                    print(f"  {'!'*50}")

                if not resources["can_run"]:
                    print(f"\n  ⚠️  Warning: Model may not run well on this system.")
                    print(f"  Consider a smaller variant (e.g., '{model}:1b' or '{model}:3b').")
                    print(f"{'='*60}")

                    # Ask if they want to continue
                    if not auto_download:
                        try:
                            response = input(f"\n  Continue anyway? [y/N]: ").strip().lower()
                            if response not in ['y', 'yes']:
                                raise RuntimeError(
                                    f"Model '{model}' may be too large for this system. "
                                    f"Try a smaller variant like '{model}:3b' or '{model}:1b'."
                                )
                        except (EOFError, KeyboardInterrupt):
                            raise RuntimeError("Operation cancelled by user.")

                print()  # Add spacing

    print(f"Using provider: {provider}, model: {model}")

    # Initialize client
    client = UnifiedLLMClient(provider=provider, api_key=api_key, model=model)

    # Build category string and schema
    categories_str = "\n".join(f"{i + 1}. {cat}" for i, cat in enumerate(categories))
    json_schema = build_json_schema(categories) if use_json_schema else None

    # Print categories
    print(f"\nCategories to classify ({len(categories)} total):")
    for i, cat in enumerate(categories, 1):
        print(f"  {i}. {cat}")
    print()

    # Build prompt template
    def build_prompt(response_text: str) -> list:
        """Build the classification prompt for a single response."""
        survey_context = f"A respondent was asked: {survey_question}." if survey_question else ""

        if chain_of_thought:
            user_content = f"""{survey_context}

Categorize this survey response "{response_text}" into the following categories that apply:
{categories_str}

Let's think step by step:
1. First, identify the main themes mentioned in the response
2. Then, match each theme to the relevant categories
3. Finally, assign 1 to matching categories and 0 to non-matching categories

Provide your answer in JSON format where the category number is the key and "1" if present, "0" if not."""
        else:
            user_content = f"""{survey_context}
Categorize this survey response "{response_text}" into the following categories that apply:
{categories_str}

Provide your answer in JSON format where the category number is the key and "1" if present, "0" if not."""

        return [
            {"role": "system", "content": "You are an expert at categorizing survey responses. Return results as JSON."},
            {"role": "user", "content": user_content},
        ]

    # Process each response
    results = []
    extracted_jsons = []

    # Use two-step approach for Ollama (more reliable JSON output)
    use_two_step = (provider == "ollama")

    if use_two_step:
        print("Using two-step classification for Ollama (classify → format JSON)")

    for response in tqdm(survey_input, desc="Classifying responses"):
        if pd.isna(response):
            results.append(("Skipped NaN", "Skipped NaN input"))
            extracted_jsons.append('{"1":"e"}')
            continue

        if use_two_step:
            # Two-step approach for Ollama: separate classification from JSON formatting
            json_result, error = ollama_two_step_classify(
                client=client,
                response_text=response,
                categories=categories,
                categories_str=categories_str,
                survey_question=survey_question,
                creativity=creativity,
                max_retries=5,
            )

            if error:
                results.append((json_result, error))
            else:
                results.append((json_result, None))
            extracted_jsons.append(json_result)

        else:
            # Standard single-call approach for cloud providers
            messages = build_prompt(response)
            reply, error = client.complete(
                messages=messages,
                json_schema=json_schema,
                creativity=creativity,
            )

            if error:
                results.append((None, error))
                extracted_jsons.append('{"1":"e"}')
            else:
                results.append((reply, None))
                extracted_jsons.append(extract_json(reply))

    # Build output DataFrame
    normalized_data_list = []
    for json_str in extracted_jsons:
        try:
            parsed = json.loads(json_str)
            normalized_data_list.append(pd.json_normalize(parsed))
        except json.JSONDecodeError:
            normalized_data_list.append(pd.DataFrame({"1": ["e"]}))

    normalized_data = pd.concat(normalized_data_list, ignore_index=True)

    # Create main DataFrame
    df = pd.DataFrame({
        'survey_input': pd.Series(survey_input).reset_index(drop=True),
        'model_response': [r[0] for r in results],
        'error': [r[1] for r in results],
        'json': pd.Series(extracted_jsons).reset_index(drop=True),
    })

    df = pd.concat([df, normalized_data], axis=1)

    # Rename category columns
    df = df.rename(columns=lambda x: f'category_{x}' if str(x).isdigit() else x)

    # Process category columns
    cat_cols = [col for col in df.columns if col.startswith('category_')]

    # Identify invalid rows
    has_invalid = df[cat_cols].apply(
        lambda col: pd.to_numeric(col, errors='coerce').isna() & col.notna()
    ).any(axis=1)

    df['processing_status'] = (~has_invalid).map({True: 'success', False: 'error'})
    df.loc[has_invalid, cat_cols] = pd.NA

    # Convert to numeric
    for col in cat_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Fill NaN with 0 for valid rows
    df.loc[~has_invalid, cat_cols] = df.loc[~has_invalid, cat_cols].fillna(0)

    # Convert to Int64
    df[cat_cols] = df[cat_cols].astype('Int64')

    # Create categories_id
    df['categories_id'] = df[cat_cols].apply(
        lambda x: ','.join(x.dropna().astype(int).astype(str)), axis=1
    )

    if filename:
        df.to_csv(filename, index=False)
        print(f"\nResults saved to {filename}")

    return df
